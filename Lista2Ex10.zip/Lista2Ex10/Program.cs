﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Retangulo area1;
            area1 = new Retangulo();



            Console.Write("Informe o valor da base do retângulo em (m): ");
            area1.setBas(int.Parse(Console.ReadLine()));

            Console.Write("Informe o valor da altura do retângulo em (m): ");
            area1.setAlt(int.Parse(Console.ReadLine()));

            area1.calcular();



            Console.WriteLine("{0}", area1.getAreaClas());
        }
    }
}
