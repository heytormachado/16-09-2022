﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex10
{
    internal class Retangulo
    {
        private double bas;
        private double alt;
        private double area;
        private string areaClas;

        public Retangulo()
        {
            this.bas = 0;
            this.alt = 0;
        }
        public Retangulo(double bas, double alt)
        {
            this.bas = bas;
            this.alt = alt;
        }

        public void setBas(double bas)
        {
            this.bas = bas;
        }
        public void setAlt(double alt)
        {
            this.alt = alt;
        }
        public double getBas()
        {
            return this.bas;
        }
        public double getAlt()
        {
            return this.alt;
        }

        public string getAreaClas()
        {
            return this.areaClas;
        }
        public void calcular()
        {
            this.area = this.bas * this.alt;

            if (this.area > 100)
            {
                this.areaClas = "Terreno Grande";
            }
            else
            {
                this.areaClas = "Terreno Pequeno";
            }

        }
    }
}
