﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex7
{
    internal class Dolar
    {
        private double cotDolar;
        private double dol;
        private double reais;

        public Dolar()
        {
            this.dol = 0;
            this.cotDolar = 0;
        }

        public Dolar(double dol, double cotDolar)
        {
            this.dol = dol;
            this.cotDolar = cotDolar;
        }

        public void setCotDolar(double cotDolar)
        {
            this.cotDolar = cotDolar;
        }
        public void setDolar(double dol)
        {
            this.dol = dol;
        }

        public double getCotDolar()
        {
            return this.cotDolar;
        }
        public double getDolar()
        {
            return this.dol;
        }

        public double getReais()
        {
            return this.reais;
        }

        public void operacao()
        {
            this.reais = this.cotDolar * this.dol;
        }
    }
}
