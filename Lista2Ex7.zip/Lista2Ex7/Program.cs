﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dolar dolar1;
            dolar1 = new Dolar();

            Console.WriteLine("Informe o valor da cotação de dolar em R$: ");
            dolar1.setCotDolar(double.Parse(Console.ReadLine()));

            Console.WriteLine("Informe o valor de dolares em U$: ");
            dolar1.setDolar(double.Parse(Console.ReadLine()));

            dolar1.operacao();
            Console.WriteLine("O resultado em Reais é R${0}", dolar1.getReais());
        }
    }
}
