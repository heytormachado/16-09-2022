﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex11
{
    internal class PesoIdeal
    {
        private double p;
        private double alt;
        private double relPesoAltura;
        private string clas;

        public PesoIdeal()
        {
            this.p = 0;
            this.alt = 0;

        }

        public PesoIdeal(double p, double alt)
        {
            this.p = p; 
            this.alt = alt;
        }
        public void setP(double p)
        {
            this.p = p;
        }
        public void setAlt(double alt)
        {
            this.alt = alt;
        }
        public double getP()
        {
            return this.p;
        }
        public double setAlt()
        {
            return this.alt;
        }
        public string getClassificacao()
        {
            return this.clas;
        }
        public void calcular()
        {
            this.relPesoAltura = this.p / Math.Pow(this.alt, 2);

            if (this.relPesoAltura < 20)
            {
                clas = "Abaixo do Peso";
            }
            else
            {
                if (this.relPesoAltura < 25)
                {
                    clas = "Peso Ideal";
                }
                else
                {
                    clas = "Acima do Peso";
                }
            }
        }
    }

}
