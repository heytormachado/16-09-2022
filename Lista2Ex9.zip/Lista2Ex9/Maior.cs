﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex9
{
    internal class Maior
    {
        private double n1;
        private double n2;
        private int maior;

        public Maior()
        {
            this.n1 = 0;
            this.n2 = 0;
        }
        public Maior(double n1, double n2)
        {
            this.n1 = n1;
            this.n2 = n2;
        }
        public void setN1(double n1)
        {
            this.n1 = n1;
        }
        public void setN2(double n2)
        {
            this.n2 = n2;
        }
        public double getN2()
        {
            return this.n2;
        }
        public double getN1()
        {
            return this.n1;
        }
        public void comparar1()
        {
            if (this.n1 > this.n2)
            {
                this.maior = 1;
            }
            else
            if (this.n1 < this.n2)
            {
                this.maior = 2;
            }
            else
            {
                this.maior = 0;
            }
        }

        public int getM()
        {
            return this.maior;
        }
    }
}
