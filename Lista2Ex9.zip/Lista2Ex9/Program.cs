﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Maior maior1;
            maior1 = new Maior();


            Console.WriteLine("Digite o primeiro valor");
            maior1.setN1(double.Parse(Console.ReadLine()));
            Console.WriteLine("Digite o segundo valor");
            maior1.setN2(double.Parse(Console.ReadLine()));


            maior1.comparar1();




            Console.WriteLine((maior1.getM() == 0 ? "Valores iguais" : (maior1.getM() == 1 ? "O 1º é maior" : "O 2º é maior")));
        }
    }
}
