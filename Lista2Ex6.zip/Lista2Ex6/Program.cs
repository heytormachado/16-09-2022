﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Quilometro converte1;
            converte1 = new Quilometro();

            Console.Write("Digite o valor em milhas maritimas: ");
            converte1.setMilmarit(double.Parse(Console.ReadLine()));



            converte1.calcular();

            Console.WriteLine("o Valor em Quilometro é: {0}m ",
                converte1.getKm());
        }
    }
}
