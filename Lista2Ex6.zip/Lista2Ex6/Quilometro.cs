﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex6
{
    internal class Quilometro
    {
        private double km;
        private double milmarit;

        public Quilometro()
        {
            this.km = 0;
        }
        public Quilometro(double km)
        {
            this.km = km;
        }

        public void setMilmarit(double milmarit)
        {
            this.milmarit = milmarit;
        }

        public double getMilmarit()
        {
            return this.milmarit;
        }


        public double getKm()
        {
            return this.km;
        }
        public void calcular()
        {
            this.km = this.milmarit * 1.852;
        }
    }
}
