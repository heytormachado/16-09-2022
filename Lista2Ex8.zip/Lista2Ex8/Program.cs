﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Maior maior1;
            maior1 = new Maior();


            Console.Write("Informe o primeiro valor:");
            maior1.setN1(double.Parse(Console.ReadLine()));
            Console.Write("Informe o segundo valor:");
            maior1.setN2(double.Parse(Console.ReadLine()));

            maior1.comparar1();
            maior1.comparar2();

            Console.WriteLine("O maior valor digitado foi: {0}", maior1.getMaior());
        }
    }
}
