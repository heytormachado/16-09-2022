﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Retangulo area1;
            area1 = new Retangulo();

            Console.Write("Digite o valor da base do retângulo: ");
            area1.setB(int.Parse(Console.ReadLine()));

            Console.Write("Digite o valor da altura do retângulo: ");
            area1.setH(int.Parse(Console.ReadLine()));

            area1.calcular();

            Console.WriteLine("A área do retângulo de base {0} e altura {1} é {2}m²",
                area1.getB(), area1.getH(), area1.getArea());
        }
    }
}
