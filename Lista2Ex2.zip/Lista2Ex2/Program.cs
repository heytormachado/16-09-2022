﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Quadrado area1;
            area1 = new Quadrado();

            Console.Write("Digite o valor da aresta do quadrado: ");
            area1.setAresta(int.Parse(Console.ReadLine()));


            area1.calcular();

            Console.WriteLine("A área do quadrado de aresta {0} é {1} m²",
                area1.getAresta(), area1.getArea());
        }
    }
}
