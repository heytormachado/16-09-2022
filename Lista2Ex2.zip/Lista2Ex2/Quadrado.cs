﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex2
{
    internal class Quadrado
    {
        private int aresta;
        private int area;

        public Quadrado()
        {
            this.aresta = 0;
            
        }

        public Quadrado(int aresta)
        {
            this.aresta = aresta;
        }
        public void setAresta(int aresta)
        {
            this.aresta = aresta;
        }

        public int getAresta()
        {
            return this.aresta;
        }


        public int getArea()
        {
            return this.area;
        }
        public void calcular()
        {
            this.area = this.aresta * this.aresta;
        }
    }
}
